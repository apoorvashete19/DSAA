package as;


import java.rmi.*;
import java.rmi.server.*;

public class CircleImplementation extends UnicastRemoteObject implements CircleInterface {

    // Constructor that throws RemoteException
    public CircleImplementation() throws RemoteException {
        super();
    }

    // Implementing the remote method to calculate the area of the circle
    @Override
    public double area(int radius) throws RemoteException {
        double pi = 3.14;
        return pi * radius * radius;  // Area of the circle: πr²
    }

    // Implementing the remote method to calculate the perimeter (circumference) of the circle
    @Override
    public double perimeter(int radius) throws RemoteException {
        double pi = 3.14;
        return 2 * pi * radius;  // Perimeter (circumference) of the circle: 2πr
    }
}

