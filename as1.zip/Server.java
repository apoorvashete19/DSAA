package as;


import java.rmi.*;
import java.rmi.registry.*;

public class Server {
    public static void main(String[] args) {
        try {
            // Create and start the RMI registry on port 2000
            Registry reg = LocateRegistry.createRegistry(2000);
            
            // Create a new instance of CircleImplementation
            CircleImplementation ci = new CircleImplementation();
            
            // Bind the object to the registry with the name "circle"
            reg.rebind("circle", ci);
            
            System.out.println("|-|-|-|-|-|-|-|-|-|-|");
            System.out.println("Server is waiting...");
        } catch (RemoteException e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}

