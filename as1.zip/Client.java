package as;


import java.rmi.*;

public class Client {
    public static void main(String[] args) {
        try {
            // Look up the remote object "circle" from the RMI registry
            CircleInterface circle = (CircleInterface) Naming.lookup("//localhost:2000/circle");
            
            int radius = 5; // Example radius for the circle
            
            // Call remote methods on the Circle object and print the results
            System.out.println("The Area of the Circle is: " + circle.area(radius));
            System.out.println("The Perimeter of the Circle is: " + circle.perimeter(radius));
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}

